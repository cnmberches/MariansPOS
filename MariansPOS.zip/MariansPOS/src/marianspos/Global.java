package marianspos;

import java.util.ArrayList;

public class Global
{
    static String name, role, account_id, username;
    static String[] inventoryClickedItems;
    static String[] menuClickedItems;
    static String mode;
    static ArrayList<String> category_names = new ArrayList<>();
    static boolean isForAddMenu = true;
    static int totalCost;
}

